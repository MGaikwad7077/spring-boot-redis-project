package com.example.demo.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CreatePostRequest;
import com.example.demo.entity.Post;
import com.example.demo.repository.PostRepository;

@Service
public class PostService {

    @Autowired
    private PostRepository postRepository;

    public Post createPost(CreatePostRequest request) {

        Post post = new Post();

        post.setAuthorId(request.getAuthorId());
        post.setContent(request.getContent());
        post.setCreatedAt(LocalDateTime.now());

        return postRepository.save(post);
    }
}