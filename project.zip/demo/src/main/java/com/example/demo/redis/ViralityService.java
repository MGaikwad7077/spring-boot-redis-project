package com.example.demo.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class ViralityService {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public void increaseScore(Long postId, int score) {

        String key = "post:" + postId + ":virality_score";

        redisTemplate.opsForValue().increment(key, score);
    }

    public Object getScore(Long postId) {

        String key = "post:" + postId + ":virality_score";

        return redisTemplate.opsForValue().get(key);
    }
    public Long increaseBotCount(Long postId) {

        String key = "post:" + postId + ":bot_count";

        return redisTemplate.opsForValue().increment(key);
    }

    public Object getBotCount(Long postId) {

        String key = "post:" + postId + ":bot_count";

        return redisTemplate.opsForValue().get(key);
    }
}