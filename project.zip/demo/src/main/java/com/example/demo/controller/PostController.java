package com.example.demo.controller;
import com.example.demo.redis.ViralityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.CreateCommentRequest;
import com.example.demo.dto.CreatePostRequest;
import com.example.demo.entity.Comment;
import com.example.demo.entity.Post;
import com.example.demo.service.CommentService;
import com.example.demo.service.PostService;

@RestController
@RequestMapping("/api/posts")
public class PostController {

	@Autowired
	private ViralityService viralityService;
    @Autowired
    private PostService postService;

    @Autowired
    private CommentService commentService;

    @PostMapping
    public Post createPost(@RequestBody CreatePostRequest request) {
        return postService.createPost(request);
    }

    @PostMapping("/{postId}/comments")
    public Comment addComment(
            @PathVariable Long postId,
            @RequestBody CreateCommentRequest request) {

        return commentService.addComment(postId, request);
    }
    @PostMapping("/{postId}/like")
    public String likePost(@PathVariable Long postId) {

        viralityService.increaseScore(postId, 20);

        return "Post liked. Virality score increased.";
    }
}