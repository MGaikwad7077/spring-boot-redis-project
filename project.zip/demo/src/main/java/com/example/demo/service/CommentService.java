package com.example.demo.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CreateCommentRequest;
import com.example.demo.entity.Comment;
import com.example.demo.redis.ViralityService;
import com.example.demo.repository.CommentRepository;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private ViralityService viralityService;

    public Comment addComment(Long postId, CreateCommentRequest request) {

        // Vertical Cap Validation
        if (request.getDepthLevel() > 20) {
            throw new RuntimeException("Comment depth cannot exceed 20");
        }

        // Bot Logic
        if (request.getAuthorId() > 1000) {

            Long botCount = viralityService.increaseBotCount(postId);

            if (botCount > 100) {
                throw new RuntimeException("Bot reply limit exceeded!");
            }

            viralityService.increaseScore(postId, 1);

        } else {

            viralityService.increaseScore(postId, 50);
        }

        Comment comment = new Comment();

        comment.setPostId(postId);
        comment.setAuthorId(request.getAuthorId());
        comment.setContent(request.getContent());
        comment.setDepthLevel(request.getDepthLevel());
        comment.setCreatedAt(LocalDateTime.now());

        return commentRepository.save(comment);
    }
}